# YT Downloader — Full Setup Guide

Paste a YouTube URL → pick format (360p / 480p / 720p / MP3) → click Download. That's it.

---

## Step 1 — Deploy the Backend on Render (free)

1. Go to **[github.com](https://github.com)** and create an account if you don't have one
2. Click **"New repository"** → name it `yt-downloader-api` → set it to **Private** → click Create
3. Upload everything inside the **`backend/`** folder to that repo
4. Go to **[render.com](https://render.com)** → sign up (free) → click **"New Web Service"**
5. Connect your GitHub account → select `yt-downloader-api`
6. Fill in these settings:
   - **Name:** `yt-downloader-api`
   - **Runtime:** Python
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
7. Click **"Create Web Service"** → wait ~3 minutes for it to deploy
8. Copy your URL — it looks like: `https://yt-downloader-api.onrender.com`

---

## Step 2 — Set Your Backend URL in the Frontend

1. Open `frontend/index.html` in any text editor (Notepad is fine)
2. Find this line near the bottom:
   ```
   const API = "https://YOUR-APP-NAME.onrender.com";
   ```
3. Replace `YOUR-APP-NAME` with your actual Render app name. Example:
   ```
   const API = "https://yt-downloader-api.onrender.com";
   ```
4. Save the file

---

## Step 3 — Host the Frontend on GitHub Pages (free)

1. Go to GitHub → create another new repo → name it `yt-downloader` → set **Public**
2. Upload `frontend/index.html` to that repo
3. Go to repo **Settings** → **Pages** → under Source select **"main branch"** → Save
4. Your website will be live at: `https://YOUR-GITHUB-USERNAME.github.io/yt-downloader`

---

## Done! 🎉

Open your GitHub Pages URL, paste a YouTube link, pick a format, hit Download.

---

## Notes

- Render free tier **spins down** after 15 minutes of inactivity — first download after a long pause may take ~30 seconds to wake up. After that it's fast.
- For personal use only.
- To upgrade to always-on, Render's paid plan is $7/month.
